import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdmingetallbusroutesComponent } from './admingetallbusroutes.component';

describe('AdmingetallbusroutesComponent', () => {
  let component: AdmingetallbusroutesComponent;
  let fixture: ComponentFixture<AdmingetallbusroutesComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AdmingetallbusroutesComponent]
    });
    fixture = TestBed.createComponent(AdmingetallbusroutesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
