import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admingetallbusroutes',
  templateUrl: './admingetallbusroutes.component.html',
  styleUrls: ['./admingetallbusroutes.component.css'],
})
export class AdmingetallbusroutesComponent {
  constructor(private router: Router) {}

  goToAdminDashboard() {
    this.router.navigate(['/admindashboard']);
  }
}
