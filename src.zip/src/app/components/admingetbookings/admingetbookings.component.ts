import { Component } from '@angular/core';

@Component({
  selector: 'app-admingetbookings',
  templateUrl: './admingetbookings.component.html',
  styleUrls: ['./admingetbookings.component.css']
})
export class AdmingetbookingsComponent {

}
