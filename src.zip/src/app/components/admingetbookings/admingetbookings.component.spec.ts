import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdmingetbookingsComponent } from './admingetbookings.component';

describe('AdmingetbookingsComponent', () => {
  let component: AdmingetbookingsComponent;
  let fixture: ComponentFixture<AdmingetbookingsComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AdmingetbookingsComponent]
    });
    fixture = TestBed.createComponent(AdmingetbookingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
