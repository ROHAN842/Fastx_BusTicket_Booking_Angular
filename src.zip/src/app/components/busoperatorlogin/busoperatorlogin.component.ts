import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthRequest } from '../AuthRequest';
import { BusoperatorJwtClientService } from '../services/busoperator-jwt-client.service';

@Component({
  selector: 'app-busoperatorlogin',
  templateUrl: './busoperatorlogin.component.html',
  styleUrls: ['./busoperatorlogin.component.css'],
})
export class BusoperatorloginComponent {
  response: any;
  token: any;
  role: any;

  authRequest: AuthRequest = new AuthRequest();

  constructor(
    private jwtBusOperatorService: BusoperatorJwtClientService,
    private router: Router
  ) {}

  login(loginForm: NgForm) {
    this.authRequest.username = loginForm.form.value.username;
    this.authRequest.password = loginForm.form.value.password;

    this.getAccessToken(this.authRequest);
  }
  public getAccessToken(authRequest: any) {
    this.jwtBusOperatorService
      .getGeneratedToken(authRequest)
      .subscribe((genToken) => {
        this.token = genToken;
        console.log(genToken);
        // Store the token in local storage
        this.jwtBusOperatorService.storeToken(this.token);
        this.jwtBusOperatorService
          .authorizationTest(authRequest)
          .subscribe((genRole: string) => {
            this.role = genRole;
            console.log(genRole);
            this.jwtBusOperatorService.storeRole(this.role);
            if (this.role === 'ROLE_BUS_OPERATOR') {
              console.log('Navigating to admin-dashboard...');
              this.router.navigate(['/busoperatordasboard']);
            } else {
              console.log('Permission denied.');
              this.router.navigate(['/home']);
            }
          });
      });
  }
}
