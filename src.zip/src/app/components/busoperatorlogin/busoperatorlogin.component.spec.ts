import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BusoperatorloginComponent } from './busoperatorlogin.component';

describe('BusoperatorloginComponent', () => {
  let component: BusoperatorloginComponent;
  let fixture: ComponentFixture<BusoperatorloginComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [BusoperatorloginComponent]
    });
    fixture = TestBed.createComponent(BusoperatorloginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
