import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-adminaddroute',
  templateUrl: './adminaddroute.component.html',
  styleUrls: ['./adminaddroute.component.css'],
})
export class AdminaddrouteComponent {
  constructor(private router: Router) {}

  goToAdminDashboard() {
    this.router.navigate(['/admindashboard']);
  }
}
