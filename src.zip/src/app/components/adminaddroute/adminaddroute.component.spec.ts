import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminaddrouteComponent } from './adminaddroute.component';

describe('AdminaddrouteComponent', () => {
  let component: AdminaddrouteComponent;
  let fixture: ComponentFixture<AdminaddrouteComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AdminaddrouteComponent]
    });
    fixture = TestBed.createComponent(AdminaddrouteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
