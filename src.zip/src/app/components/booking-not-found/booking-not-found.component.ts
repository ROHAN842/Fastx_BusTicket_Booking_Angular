import { Component } from '@angular/core';

@Component({
  selector: 'app-booking-not-found',
  templateUrl: './booking-not-found.component.html',
  styleUrls: ['./booking-not-found.component.css']
})
export class BookingNotFoundComponent {

}
