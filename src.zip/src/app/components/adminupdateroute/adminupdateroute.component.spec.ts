import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminupdaterouteComponent } from './adminupdateroute.component';

describe('AdminupdaterouteComponent', () => {
  let component: AdminupdaterouteComponent;
  let fixture: ComponentFixture<AdminupdaterouteComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AdminupdaterouteComponent]
    });
    fixture = TestBed.createComponent(AdminupdaterouteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
