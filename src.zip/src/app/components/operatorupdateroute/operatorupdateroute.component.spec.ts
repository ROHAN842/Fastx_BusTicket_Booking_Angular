import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OperatorupdaterouteComponent } from './operatorupdateroute.component';

describe('OperatorupdaterouteComponent', () => {
  let component: OperatorupdaterouteComponent;
  let fixture: ComponentFixture<OperatorupdaterouteComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [OperatorupdaterouteComponent]
    });
    fixture = TestBed.createComponent(OperatorupdaterouteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
