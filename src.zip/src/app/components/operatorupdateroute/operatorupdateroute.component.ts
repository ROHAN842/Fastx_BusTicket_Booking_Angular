import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-operatorupdateroute',
  templateUrl: './operatorupdateroute.component.html',
  styleUrls: ['./operatorupdateroute.component.css'],
})
export class OperatorupdaterouteComponent {
  constructor(private router: Router) {}

  goToOperatorDashboard() {
    this.router.navigate(['/busoperatordasboard']);
  }
}
