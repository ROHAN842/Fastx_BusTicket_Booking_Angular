import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdmingetbusoperatorComponent } from './admingetbusoperator.component';

describe('AdmingetbusoperatorComponent', () => {
  let component: AdmingetbusoperatorComponent;
  let fixture: ComponentFixture<AdmingetbusoperatorComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AdmingetbusoperatorComponent]
    });
    fixture = TestBed.createComponent(AdmingetbusoperatorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
