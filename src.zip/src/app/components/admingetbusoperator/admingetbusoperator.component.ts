import { Component } from '@angular/core';

@Component({
  selector: 'app-admingetbusoperator',
  templateUrl: './admingetbusoperator.component.html',
  styleUrls: ['./admingetbusoperator.component.css']
})
export class AdmingetbusoperatorComponent {

}
