import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdmingetallusersComponent } from './admingetallusers.component';

describe('AdmingetallusersComponent', () => {
  let component: AdmingetallusersComponent;
  let fixture: ComponentFixture<AdmingetallusersComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AdmingetallusersComponent]
    });
    fixture = TestBed.createComponent(AdmingetallusersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
