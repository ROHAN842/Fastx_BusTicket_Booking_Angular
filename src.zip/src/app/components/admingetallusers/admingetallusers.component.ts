import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admingetallusers',
  templateUrl: './admingetallusers.component.html',
  styleUrls: ['./admingetallusers.component.css'],
})
export class AdmingetallusersComponent {
  constructor(private router: Router) {}

  goToAdminDashboard() {
    this.router.navigate(['/admindashboard']);
  }
}
