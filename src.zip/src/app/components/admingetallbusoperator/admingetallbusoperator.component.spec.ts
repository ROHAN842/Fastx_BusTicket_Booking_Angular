import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdmingetallbusoperatorComponent } from './admingetallbusoperator.component';

describe('AdmingetallbusoperatorComponent', () => {
  let component: AdmingetallbusoperatorComponent;
  let fixture: ComponentFixture<AdmingetallbusoperatorComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AdmingetallbusoperatorComponent]
    });
    fixture = TestBed.createComponent(AdmingetallbusoperatorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
