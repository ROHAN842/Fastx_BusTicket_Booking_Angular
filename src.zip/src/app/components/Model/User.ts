export interface User{
    userId?: number;
    username: string;
    password: string;
    email: string;
    firstName?: string; // Optional properties can be denoted with ?
    lastName?: string;
    phoneNumber?: string;
    address?: string;
    registrationDate?: Date;
}