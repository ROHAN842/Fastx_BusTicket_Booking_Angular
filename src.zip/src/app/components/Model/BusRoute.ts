export interface BusRoute {
  routeID: number;
  origin: string;
  destination: string;
  distanceCovered: number;
  estimatedDuration: string; // Assuming Time is represented as a string
  routeDescription: string;
}
