import { Admin } from "./Admin";
import { BusSchedule } from "./BusSchedule";

export interface BusOperator{
    operatorId?: number;
    operatorUsername: string;
    operatorPassword: string;
    operatorName: string;
    emailId: string;
    phoneNumber: string;
    registrationDate: Date;
}