import { Admin } from "./Admin";

export interface BusSchedule{
    scheduleID?: number;
    busNumber: string;
    availableSeats: number;
    date: Date;
    timings: string; // Assuming Time is represented as a string
    fare: number; // Assuming BigDecimal is represented as a number
    status: Status;
    amenities: Amenities[];
    busType: BusType;
    busRouteId: number; // Define BusRoute interface if needed
    operatorId?: number; // Define BusOperator interface if needed
}

export enum Status {
    ACTIVE = 'ACTIVE',
    INACTIVE = 'INACTIVE'
  }
  
  export enum BusType {
    SLEEPER_WITH_AC = 'SLEEPER_WITH_AC',
    SLEEPER_WITHOUT_AC = 'SLEEPER_WITHOUT_AC',
    SEAT_WITH_AC = 'SEAT_WITH_AC',
    SEAT_WITHOUT_AC = 'SEAT_WITHOUT_AC'
  }
  
  export enum Amenities {
    WATER_BOTTLE = 'WATER_BOTTLE',
    CHARGING_POINT = 'CHARGING_POINT',
    TV = 'TV',
    BLANKET = 'BLANKET'
  }