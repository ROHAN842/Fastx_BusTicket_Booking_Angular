export interface Booking {
    bookingID?: number;
    totalNumberOfSeats: number;
    bookingDate: Date;
    paymentStatus: PaymentStatus;
    paymentDate?: Date; // Optional property for paymentDate
    refundStatus: RefundStatus;
    userId: number; // Define User interface if needed
    busScheduleId: number; // Define BusSchedule interface if needed
}

export enum PaymentStatus {
    PENDING = 'PENDING',
    COMPLETED = 'COMPLETED',
  }
  
  export enum RefundStatus {
    PENDING = 'PENDING',
    PROCESSED = 'PROCESSED',
    NOT_REQUIRED = 'NOT_REQUIRED',
  }