import { BusOperator } from "./BusOperator";
import { User } from "./User";

export interface Admin{
    adminId?: number;
    adminUsername: string;
    adminPassword: string;
    emailId: string;
    phoneNo?: string; // Optional properties can be denoted with ?
    registrationDate?: Date;
}