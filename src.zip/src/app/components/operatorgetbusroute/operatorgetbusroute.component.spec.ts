import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OperatorgetbusrouteComponent } from './operatorgetbusroute.component';

describe('OperatorgetbusrouteComponent', () => {
  let component: OperatorgetbusrouteComponent;
  let fixture: ComponentFixture<OperatorgetbusrouteComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [OperatorgetbusrouteComponent]
    });
    fixture = TestBed.createComponent(OperatorgetbusrouteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
