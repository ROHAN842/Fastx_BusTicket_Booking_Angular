import { Component } from '@angular/core';
import { BusRoute } from '../Model/BusRoute';
import { UserJwtClientService } from '../services/user-jwt-client.service';
import { UserServiceService } from '../services/user-service.service';
import { BusoperatorServiceService } from '../services/busoperator-service.service';

@Component({
  selector: 'app-operatorgetbusroute',
  templateUrl: './operatorgetbusroute.component.html',
  styleUrls: ['./operatorgetbusroute.component.css'],
})
export class OperatorgetbusrouteComponent {
  buses: BusRoute[] = [];
  sourceCity: string = ''; // Define sourceCity property
  destinationCity: string = ''; // Define destinationCity property

  constructor(
    private userJwtService: UserJwtClientService,
    private busoperatorService: BusoperatorServiceService
  ) {}

  onSubmit(sourceCity: string, destinationCity: string) {
    this.busoperatorService
      .getBusRouteByOriginAndDestination(sourceCity, destinationCity)
      .subscribe(
        (data: BusRoute[]) => {
          this.buses = data;
          console.log(this.buses);
        },
        (error) => {
          console.log('error: ', error);
        }
      );
  }

  deleteById(routeId: number) {
    this.busoperatorService.deleteBusRoute(routeId).subscribe(
      (response) => {
        alert(`Bus route with ID ${routeId} deleted successfully: ${response}`);
      },
      (error) => {
        console.error('Error deleting bus route:', error);
      }
    );
  }
}
