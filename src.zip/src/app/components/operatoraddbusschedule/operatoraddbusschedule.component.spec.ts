import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OperatoraddbusscheduleComponent } from './operatoraddbusschedule.component';

describe('OperatoraddbusscheduleComponent', () => {
  let component: OperatoraddbusscheduleComponent;
  let fixture: ComponentFixture<OperatoraddbusscheduleComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [OperatoraddbusscheduleComponent]
    });
    fixture = TestBed.createComponent(OperatoraddbusscheduleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
