import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-operatoraddbusschedule',
  templateUrl: './operatoraddbusschedule.component.html',
  styleUrls: ['./operatoraddbusschedule.component.css'],
})
export class OperatoraddbusscheduleComponent {
  constructor(private router: Router) {}

  goToOperatorDashboard() {
    this.router.navigate(['/busoperatordasboard']);
  }
}
