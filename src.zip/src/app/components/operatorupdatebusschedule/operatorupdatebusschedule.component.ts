import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-operatorupdatebusschedule',
  templateUrl: './operatorupdatebusschedule.component.html',
  styleUrls: ['./operatorupdatebusschedule.component.css'],
})
export class OperatorupdatebusscheduleComponent {
  constructor(private router: Router) {}

  goToOperatorDashboard() {
    this.router.navigate(['/busoperatordasboard']);
  }
}
