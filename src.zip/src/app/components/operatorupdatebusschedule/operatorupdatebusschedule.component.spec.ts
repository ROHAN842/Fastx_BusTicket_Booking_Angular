import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OperatorupdatebusscheduleComponent } from './operatorupdatebusschedule.component';

describe('OperatorupdatebusscheduleComponent', () => {
  let component: OperatorupdatebusscheduleComponent;
  let fixture: ComponentFixture<OperatorupdatebusscheduleComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [OperatorupdatebusscheduleComponent]
    });
    fixture = TestBed.createComponent(OperatorupdatebusscheduleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
