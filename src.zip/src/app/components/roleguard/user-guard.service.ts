import { Injectable } from '@angular/core';
import { CanActivate, Router, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { UserJwtClientService } from '../services/user-jwt-client.service';

@Injectable({
  providedIn: 'root'
})
export class UserGuardService implements CanActivate{

  constructor(private router: Router,private jwtClientUserService:UserJwtClientService) { }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
    const userRole = localStorage.getItem('role');

    // Check if the user's role matches the expected role
    if (userRole === "ROLE_USER") {
      console.log(userRole);
      return true;
    } else {
      // Navigate to the login page or a forbidden page
      console.log(userRole);
      this.router.navigate(['/userLogin']); // navigate back to the admin login page
      return false;
    }
  }
}
