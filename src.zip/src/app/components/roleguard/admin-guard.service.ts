import { Injectable } from '@angular/core';
import { CanActivate, Router, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { AdminJwtClientService } from '../services/admin-jwt-client.service';

@Injectable({
  providedIn: 'root'
})
export class AdminGuardService implements CanActivate{

  constructor(private router: Router,private jwtClientAdminService:AdminJwtClientService) { }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
    // Get the user's role from the decoded token 
    const adminRole = localStorage.getItem('role');

    // Check if the user's role matches the expected role
    if (adminRole === "ROLE_ADMIN") {
      console.log(adminRole);
      return true;
    } else {
      // Navigate to the login page or a forbidden page
      console.log(adminRole);
      this.router.navigate(['/login']); // navigate back to the admin login page
      return false;
    }
  }
}
