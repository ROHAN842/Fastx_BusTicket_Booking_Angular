import { TestBed } from '@angular/core/testing';

import { BusoperatorGuardService } from './busoperator-guard.service';

describe('BusoperatorGuardService', () => {
  let service: BusoperatorGuardService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(BusoperatorGuardService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
