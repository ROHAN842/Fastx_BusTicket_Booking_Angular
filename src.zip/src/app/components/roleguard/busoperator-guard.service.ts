import { Injectable } from '@angular/core';
import {
  CanActivate,
  Router,
  ActivatedRouteSnapshot,
  RouterStateSnapshot,
} from '@angular/router';
import { BusoperatorJwtClientService } from '../services/busoperator-jwt-client.service';

@Injectable({
  providedIn: 'root',
})
export class BusoperatorGuardService implements CanActivate {
  constructor(
    private router: Router,
    private jwtClientBusOperatorService: BusoperatorJwtClientService
  ) {}

  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): boolean {
    // Get the user's role from the decoded token
    const busOperatorRole = localStorage.getItem('role');

    // Check if the user's role matches the expected role
    if (busOperatorRole === 'ROLE_BUS_OPERATOR') {
      console.log(busOperatorRole);
      return true;
    } else {
      // Navigate to the login page or a forbidden page
      console.log(busOperatorRole);
      this.router.navigate(['/busoperatorlogin']); // navigate back to the admin login page
      return false;
    }
  }
}
