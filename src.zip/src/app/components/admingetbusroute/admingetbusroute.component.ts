import { Component } from '@angular/core';

@Component({
  selector: 'app-admingetbusroute',
  templateUrl: './admingetbusroute.component.html',
  styleUrls: ['./admingetbusroute.component.css']
})
export class AdmingetbusrouteComponent {

}
