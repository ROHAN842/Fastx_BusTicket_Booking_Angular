import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdmingetbusrouteComponent } from './admingetbusroute.component';

describe('AdmingetbusrouteComponent', () => {
  let component: AdmingetbusrouteComponent;
  let fixture: ComponentFixture<AdmingetbusrouteComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AdmingetbusrouteComponent]
    });
    fixture = TestBed.createComponent(AdmingetbusrouteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
