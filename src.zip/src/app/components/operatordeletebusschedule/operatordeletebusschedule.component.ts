import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-operatordeletebusschedule',
  templateUrl: './operatordeletebusschedule.component.html',
  styleUrls: ['./operatordeletebusschedule.component.css'],
})
export class OperatordeletebusscheduleComponent {
  constructor(private router: Router) {}

  goToOperatorDashboard() {
    this.router.navigate(['/busoperatordasboard']);
  }
}
