import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OperatordeletebusscheduleComponent } from './operatordeletebusschedule.component';

describe('OperatordeletebusscheduleComponent', () => {
  let component: OperatordeletebusscheduleComponent;
  let fixture: ComponentFixture<OperatordeletebusscheduleComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [OperatordeletebusscheduleComponent]
    });
    fixture = TestBed.createComponent(OperatordeletebusscheduleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
