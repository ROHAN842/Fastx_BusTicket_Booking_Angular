import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OperatorcheckavailableseatsComponent } from './operatorcheckavailableseats.component';

describe('OperatorcheckavailableseatsComponent', () => {
  let component: OperatorcheckavailableseatsComponent;
  let fixture: ComponentFixture<OperatorcheckavailableseatsComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [OperatorcheckavailableseatsComponent]
    });
    fixture = TestBed.createComponent(OperatorcheckavailableseatsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
