import { Component } from '@angular/core';
import { BusoperatorServiceService } from '../services/busoperator-service.service';
import { BusSchedule } from '../Model/BusSchedule';

@Component({
  selector: 'app-operatorcheckavailableseats',
  templateUrl: './operatorcheckavailableseats.component.html',
  styleUrls: ['./operatorcheckavailableseats.component.css'],
})
export class OperatorcheckavailableseatsComponent {
  schedules: BusSchedule | undefined; // Initialize the schedules property as undefined

  constructor(private busOperatorService: BusoperatorServiceService) {}

  checkSeatAvailability(scheduleId: number): void {
    // Call the service method with the provided schedule ID
    this.busOperatorService.getScheduleById(scheduleId).subscribe(
      (schedule: BusSchedule) => {
        // Assign the retrieved schedule directly
        this.schedules = schedule;
        console.log('Inside True');
        // If no schedule is found, display an error message
        console.log(schedule);
      },
      (error) => {
        console.log(error);
        console.log('Inside False');
      }
    );
  }
}
