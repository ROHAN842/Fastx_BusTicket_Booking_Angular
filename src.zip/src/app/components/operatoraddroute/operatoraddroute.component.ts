import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-operatoraddroute',
  templateUrl: './operatoraddroute.component.html',
  styleUrls: ['./operatoraddroute.component.css'],
})
export class OperatoraddrouteComponent {
  constructor(private router: Router) {}

  goToOperatorDashboard() {
    this.router.navigate(['/busoperatordasboard']);
  }
}
