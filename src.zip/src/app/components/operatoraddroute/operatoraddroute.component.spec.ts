import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OperatoraddrouteComponent } from './operatoraddroute.component';

describe('OperatoraddrouteComponent', () => {
  let component: OperatoraddrouteComponent;
  let fixture: ComponentFixture<OperatoraddrouteComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [OperatoraddrouteComponent]
    });
    fixture = TestBed.createComponent(OperatoraddrouteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
