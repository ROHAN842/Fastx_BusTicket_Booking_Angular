import { Component } from '@angular/core';

@Component({
  selector: 'app-busoperatorsignup',
  templateUrl: './busoperatorsignup.component.html',
  styleUrls: ['./busoperatorsignup.component.css']
})
export class BusoperatorsignupComponent {

}
