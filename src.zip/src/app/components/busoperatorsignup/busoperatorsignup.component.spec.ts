import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BusoperatorsignupComponent } from './busoperatorsignup.component';

describe('BusoperatorsignupComponent', () => {
  let component: BusoperatorsignupComponent;
  let fixture: ComponentFixture<BusoperatorsignupComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [BusoperatorsignupComponent]
    });
    fixture = TestBed.createComponent(BusoperatorsignupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
