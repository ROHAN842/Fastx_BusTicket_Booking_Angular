import { Component } from '@angular/core';
import { BusoperatorServiceService } from '../services/busoperator-service.service';
import { Booking } from '../Model/Booking';

@Component({
  selector: 'app-operatorgetbookings',
  templateUrl: './operatorgetbookings.component.html',
  styleUrls: ['./operatorgetbookings.component.css'],
})
export class OperatorgetbookingsComponent {
  bookingsByScheduleId: Booking[] | undefined;
  bookingsByUserId: Booking[] | undefined;

  constructor(private busOperatorService: BusoperatorServiceService) {}

  // Method to get bookings by Schedule ID
  getBookingsByScheduleId(scheduleId: number): void {
    this.busOperatorService
      .getBookingsByScheduleId(scheduleId)
      .subscribe((bookings) => {
        this.bookingsByScheduleId = bookings;
      });
  }

  // Method to get bookings by User ID
  getBookingsByUserId(userId: number): void {
    this.busOperatorService
      .getBookingsByUserId(userId)
      .subscribe((bookings) => {
        this.bookingsByUserId = bookings;
      });
  }
}
