import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OperatorgetbookingsComponent } from './operatorgetbookings.component';

describe('OperatorgetbookingsComponent', () => {
  let component: OperatorgetbookingsComponent;
  let fixture: ComponentFixture<OperatorgetbookingsComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [OperatorgetbookingsComponent]
    });
    fixture = TestBed.createComponent(OperatorgetbookingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
