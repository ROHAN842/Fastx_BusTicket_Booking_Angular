import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BusoperatorJwtClientService } from '../services/busoperator-jwt-client.service';
@Component({
  selector: 'app-operatordashboard',
  templateUrl: './operatordashboard.component.html',
  styleUrls: ['./operatordashboard.component.css'],
})
export class OperatordashboardComponent implements OnInit {
  constructor(
    private router: Router,
    private busoperatorjwtservice: BusoperatorJwtClientService
  ) {}

  public logout() {
    this.busoperatorjwtservice.clearStoredRole();
    this.busoperatorjwtservice.clearStoredToken();
    this.router.navigate(['/']);
  }

  ngOnInit(): void {}

  navigateTo(route: string): void {
    this.router.navigate([route]);
  }
}
