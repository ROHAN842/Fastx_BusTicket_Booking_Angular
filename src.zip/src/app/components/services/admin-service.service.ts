import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Booking } from '../Model/Booking';
import { BusRoute } from '../Model/BusRoute';
import { User } from '../Model/User';
import { BusOperator } from '../Model/BusOperator';

@Injectable({
  providedIn: 'root',
})
export class AdminServiceService {
  baseUrl: string = 'http://localhost:8080/api/admins';

  constructor(private httpClient: HttpClient) {}

  private getHeaders(): HttpHeaders {
    const token = localStorage.getItem('jwtToken');
    return new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
    });
  }

  deleteUserAccount(userId: number): Observable<any> {
    return this.httpClient.delete<any>(this.baseUrl + 'delete/' + userId, {
      headers: this.getHeaders(),
      responseType: 'text' as 'json',
    });
  }

  deleteBusOperatorAccount(operatorId: number): Observable<any> {
    return this.httpClient.delete<any>(this.baseUrl + 'delete/' + operatorId, {
      headers: this.getHeaders(),
      responseType: 'text' as 'json',
    });
  }

  getBookingsByUserId(userId: number): Observable<Booking> {
    return this.httpClient.get<Booking>(
      this.baseUrl + 'get-booking-for-userid/' + userId,
      { headers: this.getHeaders() }
    );
  }

  getAllBusRoutes(): Observable<BusRoute[]> {
    return this.httpClient.get<BusRoute[]>(this.baseUrl + 'getallbusroutes', {
      headers: this.getHeaders(),
    });
  }

  addBusRoute(body: BusRoute): Observable<BusRoute> {
    return this.httpClient.post<BusRoute>(
      this.baseUrl + 'add-bus-route',
      body,
      { headers: this.getHeaders(), responseType: 'text' as 'json' }
    );
  }

  updateBusRoute(body: BusRoute, routeId: number): Observable<BusRoute> {
    return this.httpClient.post<BusRoute>(
      this.baseUrl + 'update-bus-route/' + routeId,
      body,
      { headers: this.getHeaders(), responseType: 'text' as 'json' }
    );
  }

  deleteBusRoute(routeId: number): Observable<any> {
    return this.httpClient.delete<any>(
      this.baseUrl + 'delete-bus-route-by-id/' + routeId,
      { headers: this.getHeaders(), responseType: 'text' as 'json' }
    );
  }

  getBusRouteByOriginAndDestination(
    origin: string,
    destination: string
  ): Observable<BusRoute[]> {
    return this.httpClient.get<BusRoute[]>(
      this.baseUrl +
        'get-busroute-by-origin-destination/' +
        origin +
        '/' +
        destination,
      { headers: this.getHeaders() }
    );
  }

  getAllUsers(): Observable<User[]> {
    return this.httpClient.get<User[]>(this.baseUrl + 'get-all-users', {
      headers: this.getHeaders(),
    });
  }

  getAllBusOperators(): Observable<BusOperator[]> {
    return this.httpClient.get<BusOperator[]>(
      this.baseUrl + 'get-all-bus-operators',
      { headers: this.getHeaders() }
    );
  }

  getBusOperatorById(operatorId: number): Observable<BusOperator> {
    return this.httpClient.get<BusOperator>(
      this.baseUrl + 'get-bus-operator-by-id/' + operatorId,
      { headers: this.getHeaders() }
    );
  }
}
