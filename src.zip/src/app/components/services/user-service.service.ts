import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { User } from '../Model/User';
import { Observable } from 'rxjs';
import { BusRoute } from '../Model/BusRoute';
import { Booking } from '../Model/Booking';
import { BusSchedule } from '../Model/BusSchedule';

@Injectable({
  providedIn: 'root',
})
export class UserServiceService {
  constructor(private httpClient: HttpClient) {}

  baseUrl: string = 'http://localhost:8080/api/users/';

  private getHeaders(): HttpHeaders {
    const token = localStorage.getItem('jwtToken');
    let headers = new HttpHeaders({
      'content-type': 'application/json',
      'access-control-allow-origin': 'http://localhost:4200',
    });

    if (token) {
      headers = headers.set('Authorization', `Bearer ${token}`);
    }

    return headers;
  }

  registerUser(body: User): Observable<User> {
    return this.httpClient.post<User>(this.baseUrl + 'register-user', body, {
      responseType: 'text' as 'json',
    });
  }

  getBusRouteByOriginAndDestination(
    origin: string,
    destination: string
  ): Observable<BusRoute[]> {
    console.log(this.getHeaders());
    return this.httpClient.get<BusRoute[]>(
      this.baseUrl +
        'get-busroute-by-origin-destination/' +
        origin +
        '/' +
        destination,
      { headers: this.getHeaders() }
    );
  }

  bookTickets(body: Booking): Observable<Booking> {
    return this.httpClient.post<Booking>(
      this.baseUrl + 'book-your-tickets',
      body,
      { headers: this.getHeaders(), responseType: 'text' as 'json' }
    );
  }

  bookingHistory(userId: number): Observable<Booking[]> {
    return this.httpClient.get<Booking[]>(
      this.baseUrl + 'get-booking-history/' + userId,
      { headers: this.getHeaders(), responseType: 'text' as 'json' }
    );
  }

  cancelBooking(bookingId: number): Observable<any> {
    return this.httpClient.delete<any>(
      this.baseUrl + 'cancel-booking/' + bookingId,
      { headers: this.getHeaders(), responseType: 'text' as 'json' }
    );
  }

  updateUser(body: User, userId: number): Observable<User> {
    return this.httpClient.put<User>(
      this.baseUrl + 'update-user/' + userId,
      body,
      { headers: this.getHeaders(), responseType: 'text' as 'json' }
    );
  }

  getAvailableSchedulesById(routeID: number): Observable<BusSchedule[]> {
    return this.httpClient.get<BusSchedule[]>(
      this.baseUrl + 'get-bus-schedule-by-route-id/' + routeID,
      { headers: this.getHeaders() }
    );
  }
}
