import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { BusRoute } from '../Model/BusRoute';
import { BusOperator } from '../Model/BusOperator';
import { BusSchedule } from '../Model/BusSchedule';
import { Booking } from '../Model/Booking';
import { User } from '../Model/User';

@Injectable({
  providedIn: 'root',
})
export class BusoperatorServiceService {
  baseUrl: string = 'http://localhost:8080/api/busoperators/';

  constructor(private httpClient: HttpClient) {}

  // private getHeaders(): HttpHeaders {
  //   const token = localStorage.getItem('jwtToken');
  //   return new HttpHeaders({
  //     'Content-Type': 'application/json',
  //     Authorization: `Bearer ${token}`,
  //   });
  // }

  private getHeaders(): HttpHeaders {
    const token = localStorage.getItem('jwtToken');
    console.log('Bearer ' + token);

    let headers = new HttpHeaders({
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': 'http://localhost:4200',
    });

    if (token) {
      headers = headers.set('Authorization', `Bearer ${token}`);
    }

    console.log(headers); // Log headers to verify

    return headers;
  }
  getBusRouteByOriginAndDestination(
    origin: string,
    destination: string
  ): Observable<BusRoute[]> {
    return this.httpClient.get<BusRoute[]>(
      this.baseUrl +
        'get-busroute-by-origin-destination/' +
        origin +
        '/' +
        destination,
      { headers: this.getHeaders() }
    );
  }

  registerBusOperator(body: BusOperator): Observable<BusOperator> {
    return this.httpClient.post<BusOperator>(
      this.baseUrl + 'register-bus-operator',
      body,
      { responseType: 'text' as 'json' }
    );
  }

  addBusRoute(body: BusRoute): Observable<BusRoute> {
    return this.httpClient.post<BusRoute>(
      this.baseUrl + 'add-bus-route',
      body,
      { headers: this.getHeaders(), responseType: 'text' as 'json' }
    );
  }

  updateBusRoute(body: BusRoute, routeId: number): Observable<BusRoute> {
    return this.httpClient.post<BusRoute>(
      this.baseUrl + 'update-bus-route/' + routeId,
      body,
      { headers: this.getHeaders(), responseType: 'text' as 'json' }
    );
  }

  deleteBusRoute(routeId: number): Observable<any> {
    return this.httpClient.delete<any>(
      this.baseUrl + 'delete-bus-route-by-id/' + routeId,
      { headers: this.getHeaders(), responseType: 'text' as 'json' }
    );
  }

  addBusSchedule(body: BusSchedule): Observable<BusSchedule> {
    return this.httpClient.post<BusSchedule>(
      this.baseUrl + 'add-bus-schedule',
      body,
      { headers: this.getHeaders(), responseType: 'text' as 'json' }
    );
  }

  // checkIfSeatAvailable(scheduleId: number): Observable<boolean> {
  //   return this.httpClient.get<boolean>(
  //     `${this.baseUrl}check-if-seat-available/${scheduleId}`,
  //     { headers: this.getHeaders() }
  //   );
  // }

  getScheduleById(scheduleId: number): Observable<BusSchedule> {
    return this.httpClient.get<BusSchedule>(
      `${this.baseUrl}check-if-seat-available/${scheduleId}`,
      { headers: this.getHeaders() }
    );
  }

  updateBusSchedule(
    body: BusSchedule,
    scheduleId: number
  ): Observable<BusSchedule> {
    return this.httpClient.post<BusSchedule>(
      this.baseUrl + 'edit-bus-schedule/' + scheduleId,
      body,
      { headers: this.getHeaders(), responseType: 'text' as 'json' }
    );
  }

  deleteBusSchedule(scheduleId: number): Observable<any> {
    return this.httpClient.delete<any>(
      this.baseUrl + 'delete-bus-schedule-by-id/' + scheduleId,
      { headers: this.getHeaders(), responseType: 'text' as 'json' }
    );
  }

  // getBookingsByScheduleId(scheduelId: number): Observable<Booking> {
  //   return this.httpClient.get<Booking>(
  //     this.baseUrl + 'get-bookings-by-scheduleId/' + scheduelId,
  //     { headers: this.getHeaders() }
  //   );
  // }

  // getBookingsByUserId(userId: number): Observable<User> {
  //   return this.httpClient.get<User>(
  //     this.baseUrl + 'get-bookings-by-userId/' + userId,
  //     { headers: this.getHeaders() }
  //   );
  // }

  getBookingsByScheduleId(scheduelId: number): Observable<Booking[]> {
    return this.httpClient.get<Booking[]>(
      this.baseUrl + 'get-bookings-by-scheduleId/' + scheduelId,
      { headers: this.getHeaders() }
    );
  }

  getBookingsByUserId(userId: number): Observable<Booking[]> {
    return this.httpClient.get<Booking[]>(
      this.baseUrl + 'get-bookings-by-userId/' + userId,
      { headers: this.getHeaders() }
    );
  }
}
