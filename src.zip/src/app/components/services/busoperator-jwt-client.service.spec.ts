import { TestBed } from '@angular/core/testing';

import { BusoperatorJwtClientService } from './busoperator-jwt-client.service';

describe('BusoperatorJwtClientService', () => {
  let service: BusoperatorJwtClientService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(BusoperatorJwtClientService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
