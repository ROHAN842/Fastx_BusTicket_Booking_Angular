import { TestBed } from '@angular/core/testing';

import { BusoperatorServiceService } from './busoperator-service.service';

describe('BusoperatorServiceService', () => {
  let service: BusoperatorServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(BusoperatorServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
