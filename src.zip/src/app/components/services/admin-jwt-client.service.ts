import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class AdminJwtClientService {
  baseUrl: string = 'http://localhost:8080/api/admins';

  role: any = '';

  constructor(private httpClient: HttpClient) {}

  getGeneratedToken(requestBody: any) {
    return this.httpClient.post(this.baseUrl + '/admin-login', requestBody, {
      responseType: 'text' as 'json',
    });
  }

  authorizationTest(requestBody: any) {
    this.role = this.httpClient.get<string>(
      this.baseUrl + '/gettherole/' + requestBody.username,
      { responseType: 'text' as 'json' }
    );

    return this.role;
  }

  storeToken(token: string): void {
    localStorage.setItem('jwtToken', token);
  }

  getStoredToken(): string | null {
    return localStorage.getItem('jwtToken');
  }

  clearStoredToken(): void {
    localStorage.removeItem('jwtToken');
  }

  storeRole(role: string): void {
    localStorage.setItem('role', role);
  }

  getStoredRole(): string | null {
    return localStorage.getItem('role');
  }

  clearStoredRole(): void {
    localStorage.removeItem('role');
  }
}
